"""AETHER WATCH V1 - parametric mechanical prototype enclosure.

Units: mm. Coordinate system: X = width, Y = height, Z = front-to-rear depth.
Front face at Z=0. Main housing occupies Z=0..30; rear cover 30..32.
This is a mechanical prototype with generic purchased-component envelopes.
"""
from pathlib import Path
from copy import copy
from math import sqrt
from build123d import *

OUT = Path(__file__).parent
STL_DIR = OUT / "stl"
STL_DIR.mkdir(exist_ok=True)

# ---------- Design parameters ----------
BODY_W = 50.0
BODY_H = 68.0
BODY_D = 30.0          # main shell depth; cover brings assembly depth to 32
COVER_T = 2.0
OUTER_R = 5.0
WALL = 2.0
CAVITY_W = BODY_W - 2*WALL
CAVITY_H = BODY_H - 2*WALL
FRONT_Z = 0.0
COVER_Z = BODY_D

OLED_CX, OLED_CY = 0.0, 14.5
OLED_PCB = 27.0
OLED_VIEW_W, OLED_VIEW_H = 23.0, 13.0
LED_Y = -20.0
LED_XS = (-6.0, 6.0)
SOS_Y, SOS_Z = 9.0, 15.0
ANT_X, ANT_Z = 0.0, 15.0
BAT_CX, BAT_CY = 0.0, 6.0
BAT_Z0, BAT_T = 22.5, 6.0
ESP_CX, ESP_CY = 0.0, -4.0
ESP_Z0 = 9.0

# Colors: field hardware / generic component envelopes.
C_CASE = Color(0.17, 0.20, 0.23)
C_CASE_LITE = Color(0.25, 0.29, 0.32)
C_COVER = Color(0.11, 0.13, 0.15)
C_BEZEL = Color(0.08, 0.10, 0.12)
C_PCB = Color(0.07, 0.34, 0.23)
C_MODULE = Color(0.45, 0.49, 0.51)
C_BAT = Color(0.72, 0.74, 0.75)
C_RED = Color(0.78, 0.08, 0.12)
C_GREEN = Color(0.10, 0.68, 0.30)
C_AMBER = Color(0.80, 0.53, 0.10)
C_SILVER = Color(0.62, 0.65, 0.67)
C_BLACK = Color(0.025, 0.035, 0.045)
C_BUZZER = Color(0.24, 0.26, 0.28)

# ---------- Geometry helpers ----------
def box_at(sx, sy, sz, cx, cy, cz):
    return Pos(cx, cy, cz) * Box(sx, sy, sz)

def rounded_prism(width, height, radius, z0, depth, cx=0.0, cy=0.0):
    return Pos(cx, cy, z0) * extrude(RectangleRounded(width, height, radius), amount=depth)

def cyl_z(x, y, z0, radius, height):
    return Pos(x, y, z0) * Cylinder(radius, height, align=(Align.CENTER, Align.CENTER, Align.MIN))

def cyl_x(x0, y, z, radius, length):
    return Pos(x0, y, z) * Rot(0, 90, 0) * Cylinder(radius, length, align=(Align.CENTER, Align.CENTER, Align.MIN))

def cyl_x_neg(x0, y, z, radius, length):
    return Pos(x0, y, z) * Rot(0, -90, 0) * Cylinder(radius, length, align=(Align.CENTER, Align.CENTER, Align.MIN))

def cyl_y(x, y0, z, radius, length):
    return Pos(x, y0, z) * Rot(-90, 0, 0) * Cylinder(radius, length, align=(Align.CENTER, Align.CENTER, Align.MIN))

def ring_z(x, y, z0, r_out, r_in, height):
    return cyl_z(x, y, z0, r_out, height) - cyl_z(x, y, z0-0.01, r_in, height+0.02)

def ring_x(x0, y, z, r_out, r_in, length):
    return cyl_x(x0, y, z, r_out, length) - cyl_x(x0-0.01, y, z, r_in, length+0.02)

def ring_x_neg(x0, y, z, r_out, r_in, length):
    return cyl_x_neg(x0, y, z, r_out, length) - cyl_x_neg(x0+0.01, y, z, r_in, length+0.02)

def named(shape, label, color):
    shape.label = label
    shape.color = color
    return shape

def world_frame(shape):
    """Convert design X=width, Y=height, Z=depth into CAD-standard X=width, Z=height, Y=depth.
    The front face points toward -Y and the bottom is Z=0 in assembly coordinates.
    """
    return Pos(0, 0, 35.0) * Rot(0, 0, 180) * Rot(90, 0, 0) * shape

def cable(points, radius, label, color):
    # A 3-D wire sweep must start with its circular section centered on the first path point
    # and normal to the first segment. Polyline tuples are 2-D in this API, so use 3-D edges.
    pts = [Vector(*p) for p in points]
    route = Wire([Edge.make_line(pts[i], pts[i+1]) for i in range(len(pts)-1)])
    tangent = (pts[1] - pts[0]).normalized()
    section = Plane(origin=pts[0], z_dir=tangent) * Circle(radius)
    shape = sweep(section, path=route, is_frenet=True, transition=Transition.ROUND)
    return named(shape, label, color)

def export_print_part(shape, basename, print_transform=None):
    step_path = OUT / f"{basename}.step"
    stl_path = STL_DIR / f"{basename}.stl"
    if print_transform is None:
        print_shape = shape
    else:
        print_shape = print_transform(shape)
    detached = copy(world_frame(shape))
    detached.parent = None
    export_step(detached, str(step_path))
    detached_mesh = copy(print_shape)
    detached_mesh.parent = None
    export_stl(detached_mesh, str(stl_path), tolerance=0.08, angular_tolerance=0.18)
    print(f"PRINT PART {basename}: STEP={step_path.name} STL={stl_path.relative_to(OUT)}")

# ---------- Main front housing ----------
# Base outer shell and two reinforced side-mounted lanyard eyes.
housing = rounded_prism(BODY_W, BODY_H, OUTER_R, 0, BODY_D)
for y_eye in (28.0, -28.0):
    eye = Pos(-26.0, y_eye, 15.0) * extrude(Plane.YZ * RectangleRounded(12.0, 10.0, 1.5), amount=4.0)
    housing = housing + eye

# Low protective grip ribs on the long side edges, deliberately outside SOS area.
for side in (-1, 1):
    for y_rib in (-13.0, 22.0):
        rib = box_at(1.2, 2.6, 17.0, side*25.3, y_rib, 15.0)
        housing = housing + rib

# Hollow the shell from the rear, preserving the 2 mm front panel and side walls.
cavity = rounded_prism(CAVITY_W, CAVITY_H, 3.0, WALL, BODY_D, 0, 0)
housing = housing - cavity

# Corner fastener bosses. Their centers sit in the rounded inner corners and tie into the walls.
rear_screw_xy = [(-19.0, -29.5), (19.0, -29.5), (-19.0, 29.5), (19.0, 29.5)]
for x, y in rear_screw_xy:
    boss = cyl_z(x, y, 2.0, 2.8, 26.0)
    housing = housing + boss

# Front bezel screw bosses around (not inside) the OLED carrier footprint.
bezel_screw_xy = [(-16.0, OLED_CY), (16.0, OLED_CY)]
for x, y in bezel_screw_xy:
    housing = housing + cyl_z(x, y, 2.0, 2.2, 5.0)

# OLED nest: a 27.6 x 27.6 mm inner clear pocket locates the 27 x 27 PCB with 0.3 mm per-side clearance.
oled_locator = rounded_prism(29.6, 29.6, 1.5, 1.9, 2.2, OLED_CX, OLED_CY) - rounded_prism(27.6, 27.6, 1.0, 1.85, 2.3, OLED_CX, OLED_CY)
# Ribbon exit notch on the right side of the pocket, 2.2 mm wide.
oled_locator = oled_locator - box_at(2.2, 4.0, 2.3, 14.5, 12.0, 3.0)
housing = housing + oled_locator

# 4 ESP board supports: generic board assumes four 2.4 mm corner holes.
# The upper pair sit behind the OLED PCB plane; the support bridges start 0.5 mm behind it.
esp_mount_xy = [(-11.0, 19.5), (11.0, 19.5), (-11.0, -27.5), (11.0, -27.5)]
for x, y in esp_mount_xy:
    housing = housing + box_at(4.0, 4.0, 4.5, x, y, 6.75)  # z=4.5..9
# Sidewall-supported bridges carry the corner pads without blocking OLED or wiring.
for y in (19.5, -27.5):
    housing = housing + box_at(12.0, 4.0, 4.5, 17.0, y, 6.75)
    housing = housing + box_at(12.0, 4.0, 4.5, -17.0, y, 6.75)

# Antenna base support blocks, positioned either side of the centered cable passage.
antenna_mount_xy = [(-8.5, 9.0), (8.5, 9.0), (-8.5, 21.0), (8.5, 21.0)]
for x, z in antenna_mount_xy:
    support = box_at(5.0, 7.0, 5.0, x, 30.5, z)
    housing = housing + support
# Strengthened top inner wall over the antenna feed-through; it also gives the cable channel a thick roof.
housing = housing + box_at(24.0, 5.0, 3.4, 11.0, 31.5, 15.0)

# Battery pocket rails: a 32 x 42 mm locating tray for the 30 x 40 mm LiPo.
# Side rails tie into the shell walls; end rails close the pocket with a small lead exit gap.
for side in (-1, 1):
    housing = housing + box_at(7.0, 42.0, 3.0, side*19.5, 6.0, 22.0)  # inner face at +/-16
housing = housing + box_at(33.5, 1.2, 3.0, 0, -15.2, 22.0)
housing = housing + box_at(33.5, 1.2, 3.0, 0.0, 27.2, 22.0)

# Raised protective annulus around the side SOS plunger, fused into the right bumper.
housing = housing + ring_x_neg(-24.7, SOS_Y, SOS_Z, 6.2, 3.8, 1.8)

# Front display window, recessed status-LED bores, and side / bottom connector openings.
housing = housing - rounded_prism(OLED_VIEW_W, OLED_VIEW_H, 0.8, -0.1, 2.2, OLED_CX, OLED_CY)
for x in LED_XS:
    housing = housing - cyl_z(x, LED_Y, -0.05, 2.6, 2.15)       # 5.2 mm through hole
    housing = housing - cyl_z(x, LED_Y, -0.01, 4.0, 0.85)       # protected 8 mm shallow pocket
# Switch backing frame ties the tactile switch to the inner side wall; the 3.2 mm passage clears its actuator.
switch_bracket = box_at(1.2, 8.0, 8.0, -22.6, SOS_Y, SOS_Z) - cyl_x_neg(-22.0, SOS_Y, SOS_Z, 1.6, 1.4)
housing = housing + switch_bracket
# 7 mm physical SOS opening on the right side.
housing = housing - cyl_x(-25.4, SOS_Y, SOS_Z, 3.5, 3.0)
# Bottom USB-C port: 10 mm wide x 5 mm high, through the 2 mm bottom wall.
housing = housing - box_at(10.0, 6.0, 5.0, 0.0, -34.0, 7.5)
# Lanyard eyelet holes through the reinforced side ears.
for y_eye in (28.0, -28.0):
    housing = housing - cyl_x(-26.1, y_eye, 15.0, 2.3, 4.4)
# Rear-cover screw pilots and OLED bezel screw pilots.
for x, y in rear_screw_xy:
    housing = housing - cyl_z(x, y, 2.0, 1.05, 26.2)
for x, y in bezel_screw_xy:
    housing = housing - cyl_z(x, y, -0.05, 0.9, 7.2)
# ESP mounting pilot holes aligned with the generic board's four corner holes.
for x, y in esp_mount_xy:
    housing = housing - cyl_z(x, y, 4.45, 0.85, 4.65)
# Antenna flange screw pilots and Ø6.4 mm feed-through into the main cavity.
for x, z in antenna_mount_xy:
    housing = housing - cyl_y(x, 27.0, z, 1.05, 7.3)
housing = housing - cyl_y(0.0, 28.0, ANT_Z, 3.2, 8.0)
# Inner cable grooves, 1.5 mm deep into reinforced top/right walls (no exposed outer-wall thinning).
housing = housing - box_at(23.2, 1.5, 1.8, 11.6, 31.25, 15.0)
housing = housing - box_at(1.6, 14.0, 1.8, 22.2, 24.0, 15.0)
# Reinforced exterior cable-spine rails maintain >=2 mm shell under the protected internal wire grooves.
housing = housing + box_at(1.0, 49.0, 7.0, 25.5, 3.5, 25.5)
housing = housing + box_at(1.0, 14.0, 3.0, 25.5, 24.0, 15.0)
# Protected battery cable channel on the thickened inner right side wall; 0.8 mm groove leaves 2.2 mm material.
housing = housing - box_at(1.8, 49.0, 2.0, 23.1, 3.5, 25.7)
# USB port guard rails, outside the opening; they remain within the device footprint.
for x in (-6.4, 6.4):
    housing = housing + box_at(1.4, 2.0, 5.5, x, -34.0, 7.5)

housing = named(housing, "main_front_housing", C_CASE)

# ---------- Removable rear cover ----------
cover_plate = rounded_prism(BODY_W, BODY_H, OUTER_R, BODY_D, COVER_T)
cover_lip = rounded_prism(45.0, 63.0, 2.5, 28.4, 1.6) - rounded_prism(42.6, 60.6, 1.5, 28.35, 1.7)
# Boss-relief scallops let the four corner posts enter the cover lip without binding.
for x, y in rear_screw_xy:
    cover_lip = cover_lip - cyl_z(x, y, 28.3, 3.2, 1.8)
cover = cover_plate + cover_lip
# Four lid screw clearance holes with shallow head seats.
for x, y in rear_screw_xy:
    cover = cover - cyl_z(x, y, 29.9, 1.45, 2.2)
    cover = cover - cyl_z(x, y, 31.0, 2.5, 1.05)
# Recessed 7-hole acoustic grille (one center + six on a 3.0 mm pitch radius).
speaker_xy = (0.0, -22.5)
cover = cover - cyl_z(speaker_xy[0], speaker_xy[1], 29.9, 7.6, 0.55)  # shallow recessed well
for dx, dy in [(0,0),(3,0),(-3,0),(1.5,2.6),(1.5,-2.6),(-1.5,2.6),(-1.5,-2.6)]:
    cover = cover - cyl_z(speaker_xy[0]+dx, speaker_xy[1]+dy, 29.9, 1.0, 2.2)
# Speaker locating ring rises inward from the cover; 0.5 mm radial clearance for a 12 mm buzzer.
cover = cover + ring_z(speaker_xy[0], speaker_xy[1], 24.5, 8.2, 6.5, 5.5)
# Non-compressing LiPo stop pads, 0.5 mm nominal clearance to the 6 mm pack.
for x in (-10.0, 10.0):
    cover = cover + box_at(6.0, 5.0, 1.0, x, 6.0, 29.5)   # z=29..30
cover = named(cover, "removable_rear_cover", C_COVER)

# ---------- Separate raised front OLED bezel ----------
bezel = rounded_prism(34.0, 31.0, 2.2, -1.2, 1.2, 0.0, OLED_CY)
bezel = bezel - rounded_prism(23.4, 13.4, 0.9, -1.25, 1.3, OLED_CX, OLED_CY)
for x, y in bezel_screw_xy:
    bezel = bezel - cyl_z(x, y, -1.25, 1.1, 1.35)
    bezel = bezel - cyl_z(x, y, -1.21, 1.8, 1.05)
bezel = named(bezel, "raised_oled_protective_bezel", C_BEZEL)

# ---------- Antenna housing (mechanical placeholder, cable passage open) ----------
antenna_base = box_at(22.0, 2.4, 18.0, 0.0, 35.2, 15.0)
antenna_taper = Pos(0, 34.0, 15.0) * Rot(-90, 0, 0) * Cone(9.0, 8.0, 3.0, align=(Align.CENTER, Align.CENTER, Align.MIN))
antenna_tube = cyl_y(0.0, 36.5, 15.0, 8.0, 12.5)
antenna = antenna_base + antenna_taper + antenna_tube
antenna = antenna - cyl_y(0.0, 33.8, 15.0, 5.2, 15.5)
# Four flange fastener holes; head counterbores open from the top of the flange.
for x, z in antenna_mount_xy:
    antenna = antenna - cyl_y(x, 33.9, z, 1.2, 2.8)
    antenna = antenna - cyl_y(x, 35.15, z, 1.8, 1.35)
antenna = named(antenna, "hollow_antenna_housing_placeholder", C_CASE_LITE)

# ---------- SOS button, switch envelope ----------
# Mechanical button shaft fits the 7 mm side opening; the head sits 0.3 mm below its guard.
sos_button = cyl_x_neg(-23.35, SOS_Y, SOS_Z, 2.75, 1.65) + cyl_x_neg(-25.0, SOS_Y, SOS_Z, 3.0, 1.2)
sos_button = named(sos_button, "red_sos_button_plunger", C_RED)
# Switch body is mounted to an internal side-wall bracket; actuator meets the plunger face.
sos_switch = box_at(6.0, 6.0, 4.0, -19.0, SOS_Y, SOS_Z)
sos_switch = named(sos_switch, "6mm_sos_tactile_switch_envelope", C_MODULE)
sos_actuator = cyl_x_neg(-22.0, SOS_Y, SOS_Z, 1.3, 1.35)
sos_actuator = named(sos_actuator, "sos_switch_actuator", C_BLACK)
# Guard ring is integral to the enclosure, rendered by the main housing. Add separate SOS legend plate not needed.

# ---------- Electronics: immutable generic component envelopes ----------
# OLED 27 x 27 PCB with a 23 x 13 active window; board is retained from the rear by the front bezel.
oled_pcb = box_at(27.0, 27.0, 1.6, OLED_CX, OLED_CY, 3.2)  # z=2.4..4.0
oled_pcb = named(oled_pcb, "oled_i2c_pcb_27x27", C_PCB)
oled_glass = box_at(22.8, 12.8, 0.25, OLED_CX, OLED_CY, 2.125)  # face aligned behind 23 x 13 opening
oled_glass = named(oled_glass, "oled_active_area_23x13", C_BLACK)
# Minimal pixel/status marks on the panel are geometry, not extra electronics.
# They sit on top of the black display face and indicate a blank active module.
oled_status_bar = box_at(5.2, 0.55, 0.05, -7.0, 18.0, 2.275)
oled_status_bar = named(oled_status_bar, "oled_status_pixel_bar", C_GREEN)

# Generic ESP32-C3 PCB: 28 x 52 x 1.6, vertical with USB-C at the short lower end.
esp_pcb = box_at(28.0, 52.0, 1.6, ESP_CX, ESP_CY, ESP_Z0+0.8)
for x, y in esp_mount_xy:
    esp_pcb = esp_pcb - cyl_z(x, y, ESP_Z0-0.05, 1.2, 1.7)
esp_pcb = named(esp_pcb, "esp32c3_dev_board_pcb_28x52", C_PCB)
# All C3 modules/ICs are generic board-mounted envelopes, not additional system sensors.
esp_radio = named(box_at(16.0, 13.0, 10.4, 0.0, 7.0, 15.8), "esp32c3_radio_module_envelope", C_MODULE) # z10.6..21; with PCB, 12 mm total envelope
# Main MCU package and passive blocks stay inside the 12 mm board envelope.
esp_mcu = named(box_at(7.0, 7.0, 1.5, -6.0, -5.0, 11.35), "esp32c3_mcu_package", C_BLACK)
esp_reg = named(box_at(5.0, 4.0, 1.4, 7.0, -10.0, 11.3), "board_power_regulator_envelope", C_MODULE)
esp_usb = named(box_at(9.0, 3.2, 3.0, 0.0, -31.6, 8.0), "usb_c_receptacle_envelope", C_SILVER)
# Generic battery input pads/connector at the right lower board edge, within PCB width.
esp_bat_header = named(box_at(4.0, 3.0, 1.4, 11.5, -16.0, 11.3), "battery_input_header_envelope", C_SILVER)
# Tiny reset/boot button envelopes on the board edge are left clear of the enclosure walls.
esp_boot = named(box_at(2.2, 2.2, 1.0, 10.0, -6.0, 11.1), "boot_button_envelope", C_MODULE)
esp_reset = named(box_at(2.2, 2.2, 1.0, 10.0, -1.0, 11.1), "reset_button_envelope", C_MODULE)

# LiPo is rotated in the XY plane: 30 wide x 40 tall x 6 thick, with 1 mm pocket clearance.
battery = box_at(30.0, 40.0, 6.0, BAT_CX, BAT_CY, BAT_Z0+3.0)
battery = named(battery, "lipo_3v7_30x40x6_envelope", C_BAT)

# Two through-hole 5 mm LEDs. Their body ends at the board plane; lens faces are recessed.
led_parts = []
for x, lbl, color in [(LED_XS[0], "green_system_led_5mm", C_GREEN), (LED_XS[1], "red_alert_led_5mm", C_RED)]:
    led_body = cyl_z(x, LED_Y, 2.0, 2.5, 5.0)
    led_lens = cyl_z(x, LED_Y, 0.35, 2.35, 1.75)
    led = led_body + led_lens
    led_parts.append(named(led, lbl, color))

# Rear acoustic buzzer, 12 mm dia x 5.5 mm thick, captured on the cover seat with removable adhesive.
buzzer = cyl_z(speaker_xy[0], speaker_xy[1], 24.5, 6.0, 5.5)
buzzer = named(buzzer, "12mm_rear_buzzer_envelope", C_BUZZER)

# ---------- Wiring routes in the molded channels ----------
rf_coax = cable([(0.0, 46.0, 15.0), (0.0, 31.25, 15.0), (22.2, 31.25, 15.0), (22.2, 18.0, 15.0)], 0.55, "antenna_coax_placeholder", C_AMBER)
# Paired battery leads track the protected side groove and terminate at the board's battery-input header.
lead_red = cable([(15.4, 6.0, 25.0), (22.2, 6.0, 25.0), (22.2, -20.0, 25.0), (20.0, -20.0, 25.0), (20.0, -20.0, 10.9), (20.0, -15.0, 10.9), (13.5, -15.0, 10.9)], 0.25, "battery_positive_lead", C_RED)
lead_black = cable([(16.2, 6.0, 26.2), (23.0, 6.0, 26.2), (23.0, -20.0, 26.2), (22.5, -20.0, 26.2), (22.5, -20.0, 12.1), (22.5, -17.0, 12.1), (13.5, -17.0, 12.1)], 0.25, "battery_negative_lead", C_BLACK)
# Short flexible OLED ribbon is routed around the right edge, not through the PCB footprint.
oled_flex = cable([(13.85, 12.0, 3.6), (19.0, 12.0, 3.6), (19.0, 12.0, 11.2), (14.4, 12.0, 11.2)], 0.30, "oled_signal_ribbon_placeholder", C_AMBER)

# ---------- Fasteners ----------
def screw_z(x, y, shaft_start, shaft_d, shaft_h, head_d, head_h, label):
    """Fastener axis +Z; head is at the high-Z end of the shank."""
    shaft = cyl_z(x, y, shaft_start, shaft_d/2, shaft_h)
    head = cyl_z(x, y, shaft_start+shaft_h, head_d/2, head_h)
    return named(shaft + head, label, C_SILVER)

def screw_z_front_facing(x, y, head_bottom, shaft_len, shaft_d, head_d, head_h, label):
    """Fastener inserted from the front (+Z); its head is at the low-Z end."""
    head = cyl_z(x, y, head_bottom, head_d/2, head_h)
    shaft = cyl_z(x, y, head_bottom+head_h, shaft_d/2, shaft_len)
    return named(head + shaft, label, C_SILVER)

def screw_z_rear_facing(x, y, head_bottom, shaft_len, shaft_d, head_d, head_h, label):
    """Fastener inserted from rear (-Z); its head is flush with the outside cover face."""
    shaft = cyl_z(x, y, head_bottom-shaft_len, shaft_d/2, shaft_len)
    head = cyl_z(x, y, head_bottom, head_d/2, head_h)
    return named(shaft + head, label, C_SILVER)

rear_screws = [screw_z_rear_facing(x,y,31.0,10.0,1.8,3.6,1.0,f"rear_m2_5_screw_{i+1}") for i,(x,y) in enumerate(rear_screw_xy)]
bezel_screws = [screw_z_front_facing(x,y,-1.2,6.2,1.6,3.2,1.0,f"bezel_m2_screw_{i+1}") for i,(x,y) in enumerate(bezel_screw_xy)]
# ESP board screw heads rest on the PCB; shafts fit board holes and the 1.7 mm standoff pilots.
esp_screws = [screw_z(x,y,4.5,1.6,6.1,3.4,1.0,f"esp_mount_m2_screw_{i+1}") for i,(x,y) in enumerate(esp_mount_xy)]
# Antenna screws run along +Y and sit flush in the flange counterbores.
antenna_screws = []
for i,(x,z) in enumerate(antenna_mount_xy):
    shaft = cyl_y(x, 28.5, z, 0.9, 6.7)
    head = cyl_y(x, 35.2, z, 1.55, 1.2)
    antenna_screws.append(named(shaft + head, f"antenna_m2_screw_{i+1}", C_SILVER))

# ---------- Assembly export ----------
assembled_parts = [
    housing, antenna, *antenna_screws,
    bezel, *bezel_screws,
    oled_pcb, oled_glass, oled_status_bar,
    *led_parts,
    esp_pcb, esp_radio, esp_mcu, esp_reg, esp_usb, esp_bat_header, esp_boot, esp_reset,
    *esp_screws,
    battery, buzzer,
    sos_switch, sos_actuator, sos_button,
    rf_coax, lead_red, lead_black, oled_flex,
    cover, *rear_screws,
]
assembly = Compound(children=[world_frame(p) for p in assembled_parts])
assembly.label = "AETHER_WATCH_V1_ASSEMBLED"
export_step(assembly, str(OUT / "aether_watch_assembly.step"))

# Separate printable parts in native installed coordinates (cover gets a print-bed-friendly orientation).
export_print_part(housing, "aether_watch_main_housing")
cover_print = lambda s: Pos(0, 0, 32.0) * Rot(180, 0, 0) * s
export_print_part(cover, "aether_watch_rear_cover", cover_print)
export_print_part(bezel, "aether_watch_display_bezel", lambda s: Pos(0,0,1.2) * s)
antenna_print = lambda s: Pos(0, 15.0, 0) * Rot(90, 0, 0) * Pos(0, -34.0, 0) * s
export_print_part(antenna, "aether_watch_antenna_housing", antenna_print)
export_print_part(sos_button, "aether_watch_sos_button", lambda s: Pos(0,0,26.2) * Rot(0,90,0) * s)

# ---------- Exploded assembly view file ----------
def move(shape, dx=0, dy=0, dz=0):
    return Pos(dx,dy,dz) * shape
exploded_parts = [
    housing,
    move(antenna,dy=8), *[move(s,dy=8) for s in antenna_screws],
    move(bezel,dx=28,dz=-7), *[move(s,dx=28,dz=-7) for s in bezel_screws],
    move(oled_pcb,dx=-28,dz=-4), move(oled_glass,dx=-28,dz=-4), move(oled_status_bar,dx=-28,dz=-4),
    *[move(s,dz=-6) for s in led_parts],
    move(esp_pcb,dx=28,dz=22), move(esp_radio,dx=28,dz=22), move(esp_mcu,dx=28,dz=22), move(esp_reg,dx=28,dz=22), move(esp_usb,dx=28,dz=22), move(esp_bat_header,dx=28,dz=22), move(esp_boot,dx=28,dz=22), move(esp_reset,dx=28,dz=22),
    *[move(s,dx=28,dz=22) for s in esp_screws],
    move(battery,dx=-28,dz=34), move(buzzer,dx=34,dz=44),
    sos_switch, sos_actuator, move(sos_button,dx=-4),
    rf_coax, move(lead_red,dz=3), move(lead_black,dz=3), move(oled_flex,dz=-2),
    move(cover,dx=-34,dy=15,dz=54), *[move(s,dx=-34,dy=15,dz=54) for s in rear_screws],
]
exploded = Compound(children=[world_frame(p) for p in exploded_parts])
exploded.label = "AETHER_WATCH_V1_EXPLODED"
export_step(exploded, str(OUT / "aether_watch_exploded.step"))

# Compact geometry summary for reproducibility and the drawing source.
for name, shape in [("housing",housing),("cover",cover),("bezel",bezel),("antenna",antenna),("assembly",assembly)]:
    bb = shape.bounding_box()
    sz = bb.size
    print(f"BBOX {name}: {sz.X:.2f} x {sz.Y:.2f} x {sz.Z:.2f} mm; valid={shape.is_valid}")
print(f"Wrote assembly: {OUT/'aether_watch_assembly.step'}")
