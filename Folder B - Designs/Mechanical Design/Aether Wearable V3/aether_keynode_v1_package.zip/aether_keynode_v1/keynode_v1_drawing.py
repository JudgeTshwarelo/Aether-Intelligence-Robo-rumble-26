"""Dimensioned, multi-sheet PDF derived from the validated KEYNODE STEP parts."""
from pathlib import Path
from build123d import import_step
from cadgen.eng_drawing import Sheet, eng_drawing

OUT = Path(__file__).parent
HOUSING = import_step(OUT / "keynode_v1_housing.step")
COVER = import_step(OUT / "keynode_v1_rear_cover.step")


def make_sheet(title, part_no, notes=()):
    return Sheet(
        "A3",
        scale=1.0,
        title=title,
        part_number=part_no,
        material="PETG / PLA+ prototype",
        revision="A",
        author="AETHER INTELLIGENCE",
        units="mm",
        projection="THIRD ANGLE",
        notes=list(notes),
        ink="mono",
        text_height=3.5,
    )


@eng_drawing(out=str(OUT / "keynode_v1_dimensioned_drawing.pdf"))
def draw_keynode():
    sheets = []

    # 1. Front face, principal external controls.
    sheet = make_sheet(
        "KEYNODE V1 - HOUSING FRONT",
        "AKN-V1-HSG",
        [
            "NOMINAL PROTOTYPE GEOMETRY; NO GENERAL TOLERANCE ASSIGNED.",
            "VERIFY LCD PCB, ESP32 VARIANT, USB CONNECTOR AND FASTENERS BEFORE FINAL PRINT.",
            "USB RELIEF IS PROVISIONAL; MATCH THE ACTUAL DEVKIT CONNECTOR.",
        ],
    )
    front = sheet.view(HOUSING, "front", at=(205, 148), hidden=True, centre_marks=True)
    front.overall()
    front.dim((-32.5, -17.0, 106.0), (32.5, -17.0, 106.0), orientation="h")
    front.dim((0.0, -17.0, 97.5), (0.0, -17.0, 114.5), orientation="v")
    front.hole((0.0, -17.0, 152.0), 7.0, thru=True, label="KEY LUG")
    front.hole((-6.5, -17.0, 81.5), 5.2, thru=True, count=2, label="LED")
    front.hole((0.0, -17.0, 65.0), 10.8, thru=True, count=2, label="BUTTON APERTURE")
    front.dim((-7.0, -17.0, 0.0), (7.0, -17.0, 0.0), orientation="h", offset=-8)
    front.dim((0.0, -17.0, 0.0), (0.0, -17.0, 9.0), orientation="v")
    sheets.append(sheet)

    # 2. Rear of front shell, with removable cover omitted.
    sheet = make_sheet(
        "KEYNODE V1 - SHELL REAR",
        "AKN-V1-HSG",
        ["REAR COVER SHOWN ON ITS OWN SHEET.",
         "BOSS PILOTS AND COMPONENT RAILS ARE PROVISIONAL UNTIL HARDWARE IS MEASURED."],
    )
    rear = sheet.view(HOUSING, "back", at=(205, 148), hidden=True, centre_marks=True)
    rear.overall()
    rear.hole((-44.5, 17.0, 10.0), 2.1, thru=True, count=4, label="COVER BOSS PILOT")
    rear.dim((-44.5, 17.0, 10.0), (44.5, 17.0, 10.0), orientation="h", offset=-8)
    rear.dim((44.5, 17.0, 10.0), (44.5, 17.0, 124.0), orientation="v")
    sheets.append(sheet)

    # 3. Side and top views are kept on their own sheets to avoid view overlap.
    sheet = make_sheet("KEYNODE V1 - HOUSING RIGHT", "AKN-V1-HSG")
    right = sheet.view(HOUSING, "right", at=(205, 148), hidden=True, centre_marks=True)
    right.overall()
    sheets.append(sheet)

    sheet = make_sheet("KEYNODE V1 - HOUSING TOP", "AKN-V1-HSG")
    top = sheet.view(HOUSING, "top", at=(205, 148), hidden=True, centre_marks=True)
    top.overall()
    sheets.append(sheet)

    # 5. Outside of the separate rear cover.
    sheet = make_sheet(
        "KEYNODE V1 - COVER OUTSIDE",
        "AKN-V1-CVR",
        ["NOMINAL FIT: 0.3 mm PER SIDE AT REAR RECESS; 0.4 mm PER SIDE AT LOCATING LIP.",
         "COVER: 2.0 mm FACE PLATE + 1.5 mm LOCATING LIP; FASTENER THREAD/LENGTH TBD."],
    )
    cover_back = sheet.view(COVER, "back", at=(205, 148), hidden=True, centre_marks=True)
    cover_back.overall()
    cover_back.hole((-44.5, 17.0, 10.0), 2.9, thru=True, count=4, label="SCREW CLEARANCE")
    cover_back.dim((-44.5, 17.0, 10.0), (44.5, 17.0, 10.0), orientation="h", offset=-8)
    cover_back.dim((44.5, 17.0, 10.0), (44.5, 17.0, 124.0), orientation="v")
    cover_back.hole((27.0, 17.0, 24.5), 1.8, thru=True, count=7, label="ACOUSTIC PORTS")
    sheets.append(sheet)

    sheet = make_sheet("KEYNODE V1 - COVER RIGHT", "AKN-V1-CVR")
    cover_right = sheet.view(COVER, "right", at=(205, 148), hidden=True, centre_marks=True)
    cover_right.overall()
    sheets.append(sheet)

    return sheets


if __name__ == "__main__":
    draw_keynode()
