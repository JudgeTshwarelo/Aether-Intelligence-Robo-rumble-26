# AETHER KEYNODE V1 — first-fit CAD package

**Small Device. Bigger Impact.**

This is a CAD-ready first-fit enclosure and component-layout model based on the written specification and the supplied concept images. It is not a final, measured fit to the user's physical parts: the LCD, DevKit, LEDs, switches, resistors, buzzer and generic fasteners are represented by nominal envelope solids.

## Important correction to the concept

The reference images show three front controls and a roughly 42 × 78 × 24 mm enclosure. The written specification requires exactly two round controls and a real 16×2 LCD with an approximately 80 × 36 mm PCB. Those cannot all be true at once: the compact image dimensions cannot contain that LCD module in landscape orientation. I followed the written component list and enlarged the enclosure rather than shrinking the LCD or changing the button count.

The resulting shell is **100 mm wide × 134 mm tall × 34 mm deep**, with an integrated lug extending the total height to **162 mm**. Including the raised front bezel, the shell STEP bounds are **100 × 35.2 × 162 mm**. This is a pocket communicator, not the tiny key fob shown in the reference board.

## Package contents

- `keynode_v1_layout_assembly.step` — closed layout with housing, cover, button actuators and nominal hardware envelopes.
- `keynode_v1_exploded_assembly.step` — same parts separated along the front-to-back insertion axis for assembly review.
- `keynode_v1_housing.step` / `.stl` — printable front shell with lug, LCD opening, controls, LED wells, internal rails, bosses and provisional USB relief.
- `keynode_v1_rear_cover.step` / `.stl` — removable cover with locating lip, screw clearances and buzzer grille.
- `keynode_v1_button_actuators.step` / `.stl` — the two printed round actuators.
- `keynode_v1_dimensioned_drawing.pdf` — six A3 drawing sheets at 1:1: housing front, rear, right, top, cover outside and cover right.
- `aether_keynode_v1.py` — parametric build123d generator for the STEP and STL files.
- `keynode_v1_drawing.py` — generator for the dimensioned drawing PDF.
- `review/` — saved CAD review snapshots.

The layout model contains one 16×2 LCD module, one ESP32 DevKit V1 envelope, exactly two round actuators and tactile switches, two LEDs, two current-limiting resistor envelopes, one active buzzer, and four generic cover fastener envelopes. Wires and a metal split ring are not included.

## Current nominal geometry

| Feature | Current model |
|---|---:|
| LCD PCB / visible opening | 80 × 36 mm / 65 × 17 mm |
| LCD visible character area | 64 × 16 mm |
| ESP32 DevKit V1 envelope | 52 × 28 × 12 mm nominal |
| LED holes | 2 × Ø5.2 mm, 13 mm centre spacing |
| Button apertures / caps | 2 × Ø10.8 mm apertures; round 10.2 mm face caps |
| Button separation | 16 mm centre-to-centre |
| Key-lug hole | Ø7 mm |
| Main shell | 100 × 134 × 34 mm, excluding lug |
| Cover | 97.4 × 131.4 × 3.5 mm overall; 2 mm plate + 1.5 mm locating lip |
| Main shell walls | 2.5 mm front, 3 mm perimeter walls |
| Rear acoustic grille | 7 × Ø1.8 mm ports |
| Bottom USB relief | 14 × 9 mm provisional, connector variant not confirmed |

## Validation performed

- STEP geometry loaded successfully; the housing and cover are single valid solids.
- The assembled layout passed `inspect interference`: **57 solids, 0 overlaps, 43 intended contacts, 0 floating parts**.
- The exploded view has intentional separation and is for assembly visualization, not the fit gate.
- The three print STLs are watertight and winding-consistent.
- The drawing is nominal only. No general tolerance or structural rating has been assigned.

## Before printing a functional fit-check

Measure the actual LCD PCB, backpack, connector position and maximum thickness; measure the exact ESP32 board and USB connector; confirm tactile-switch orientation and actuator travel; confirm the LED and buzzer packages; then revise the source parameters and rerun the model. The USB opening and fastener pilots are deliberately provisional. Printed fit, button actuation, cover sealing, key-lug strength and acoustic performance still need physical testing.

No battery, GPS, cellular or satellite module is modeled. The listed hardware alone does not provide positioning or a networked SOS service. Treat this as a bench prototype, not a safety-certified emergency device.

## Suggested first print

Use PETG, about 0.2 mm layer height, and a front-face-down orientation for the shell so the cavity and internal rails build upward. Print the rear cover with its outside face on the bed and the locating lip facing up. Print the actuators separately. Test-fit the actual components before installing electronics or attaching valuable keys.
