"""AETHER KEYNODE V1 - preliminary, measured-envelope enclosure concept.

All dimensions are millimeters. Coordinate system: X = width, Y = front/back
(front is negative Y), Z = device height. COTS components are envelopes only;
confirm actual hardware before printing a final fit-check or trusting the lug.
"""
from build123d import *
from pathlib import Path

OUT = Path(__file__).parent
OUT.mkdir(parents=True, exist_ok=True)

# Main outer dimensions: LCD orientation is landscape, so width must exceed
# the LCD PCB's 80 mm length. The top lug is integrated into the printed body.
BODY_W, BODY_H, BODY_D = 100.0, 134.0, 34.0
BODY_Z0 = 0.0
BODY_ZC = BODY_H / 2
FRONT_Y, BACK_Y = -BODY_D / 2, BODY_D / 2
WALL = 2.5
CAV_W, CAV_H, CAV_R, CAV_ZC = 94.0, 128.0, 7.0, 67.0
CAV_FRONT_Y = -14.5
LID_RECESS_W, LID_RECESS_H, LID_RECESS_R = 98.0, 132.0, 9.0
LID_RECESS_ZC = 67.0

# Device layout datums
LCD_CX, LCD_CZ = 0.0, 106.0
LCD_PCB_W, LCD_PCB_H = 80.0, 36.0
LCD_WINDOW_W, LCD_WINDOW_H = 65.0, 17.0
LED_X, LED_Z = (-6.5, 6.5), 81.5
BUTTON_Z = (65.0, 49.0)  # high priority red above low/ack amber
ESP_CX, ESP_CZ = 0.0, 30.0
BUZZER_X, BUZZER_Z = 27.0, 24.5

# Palette
BLACK = Color(0.055, 0.065, 0.080)
CHARCOAL = Color(0.16, 0.18, 0.21)
DARK = Color(0.085, 0.10, 0.12)
PCB_GREEN = Color(0.04, 0.32, 0.17)
LCD_BLUE = Color(0.02, 0.20, 0.42)
LCD_DARK = Color(0.015, 0.035, 0.055)
METAL = Color(0.58, 0.62, 0.66)
RED = Color(0.82, 0.08, 0.07)
AMBER = Color(0.93, 0.48, 0.04)
GREEN = Color(0.10, 0.74, 0.20)


def xz_prism(width, height, radius, z_center, y_back, depth):
    """Rounded rectangle in X-Z, extruded from y_back toward negative Y."""
    face = Pos(0, z_center, 0) * RectangleRounded(width, height, radius)
    solid = extrude(face, amount=depth)
    return Pos(0, y_back, 0) * Rot(90, 0, 0) * solid


def y_cylinder(x, z, y_center, diameter, length):
    """Cylinder axis parallel to Y, centered on (x, y_center, z)."""
    return Pos(x, y_center, z) * Rot(90, 0, 0) * Cylinder(
        diameter / 2, length,
        align=(Align.CENTER, Align.CENTER, Align.CENTER),
    )


def x_cylinder(x_center, y, z, diameter, length):
    """Cylinder axis parallel to X."""
    return Pos(x_center, y, z) * Rot(0, 90, 0) * Cylinder(
        diameter / 2, length,
        align=(Align.CENTER, Align.CENTER, Align.CENTER),
    )


def box_at(x, y, z, dx, dy, dz):
    return Pos(x, y, z) * Box(dx, dy, dz)


def ring_y(x, z, outer_d, inner_d, y_back, depth):
    outer = y_cylinder(x, z, y_back - depth / 2, outer_d, depth)
    inner = y_cylinder(x, z, y_back - depth / 2, inner_d, depth + 0.2)
    return outer - inner


def name_color(shape, label, color):
    shape.label = label
    shape.color = color
    return shape


# --- Housing shell ---
main_profile = Pos(0, BODY_ZC, 0) * RectangleRounded(BODY_W, BODY_H, 10.0)
lug_profile = Pos(0, 147.0, 0) * RectangleRounded(32.0, 30.0, 7.0)
outer = extrude(main_profile, amount=BODY_D) + extrude(lug_profile, amount=BODY_D)
outer = Pos(0, BACK_Y, 0) * Rot(90, 0, 0) * outer

# Rear cavity opening, leaving 2.5 mm front skin and 3 mm side/top/bottom walls.
cavity = xz_prism(CAV_W, CAV_H, CAV_R, CAV_ZC, BACK_Y, BACK_Y - CAV_FRONT_Y)
body = outer - cavity

# Recess for a stepped rear cover. The cover plate sits in this 2 mm back pocket.
rear_recess = xz_prism(LID_RECESS_W, LID_RECESS_H, LID_RECESS_R,
                       LID_RECESS_ZC, BACK_Y, 2.1)
body = body - rear_recess

# LCD aperture, rounded internal corners. Display area stays a real 16x2 LCD size.
lcd_aperture = xz_prism(LCD_WINDOW_W, LCD_WINDOW_H, 1.0, LCD_CZ,
                        FRONT_Y + 2.6, 2.8)
body = body - lcd_aperture

# LED bores and protective recesses: 5.2 mm package holes, 8.2 mm shallow wells.
for lx in LED_X:
    body = body - y_cylinder(lx, LED_Z, -15.75, 5.2, 3.7)
    body = body - y_cylinder(lx, LED_Z, -16.35, 8.2, 1.4)

# Button guide apertures and inner retaining counterbores.
for bz in BUTTON_Z:
    body = body - y_cylinder(0, bz, -15.5, 10.8, 3.4)
    body = body - y_cylinder(0, bz, -14.1, 12.4, 1.8)

# General USB opening at the bottom edge. This is a generous provisional
# clearance, not a connector-specific cutout; match it to the supplied DevKit.
body = body - box_at(0, 0, 4.2, 14.0, BODY_D + 2.0, 9.0)

# Reinforced through-hole in the integrated keychain lug.
body = body - y_cylinder(0, 152.0, 0.0, 7.0, BODY_D + 2.0)

# Four printed screw bosses at cover corners. Pilot holes are provisional for
# small self-tapping screws; choose hardware and re-size pilots after validation.
BOSS_POS = [(-44.5, 10.0), (44.5, 10.0), (-44.5, 124.0), (44.5, 124.0)]
for bx, bz in BOSS_POS:
    boss = y_cylinder(bx, bz, 0.4, 5.6, 25.8)  # -12.5 to +13.3
    body = body + boss
    body = body - y_cylinder(bx, bz, 0.4, 2.1, 26.2)

# Axial resistor saddles. Each printed cradle supports one resistor body while
# its leads remain available for soldered wire routing.
for rx in (-22.0, 22.0):
    saddle = box_at(rx, -5.0, 79.85, 7.0, 3.0, 0.8)  # top at z=80.25
    web = box_at(rx, -10.45, 78.95, 1.2, 8.2, 1.0)  # joins front wall to saddle
    body = body + saddle + web

# LCD mounting rails: 0.5 mm side clearance, non-obstructive top/bottom stops.
for sx in (-41.2, 41.2):
    body = body + box_at(sx, -10.1, LCD_CZ, 1.4, 8.8, LCD_PCB_H)
for sz in (87.25, 124.75):
    body = body + box_at(0, -13.55, sz, 80.8, 1.9, 1.5)

# ESP32 removable edge rails. They sit beside the PCB edge, not under solder joints.
for sx in (-15.25, 15.25):
    body = body + box_at(sx, -6.2, ESP_CZ, 1.5, 16.6, 52.0)

# Raised display bezel around the opening.
bezel_outer = xz_prism(73.0, 25.0, 3.0, LCD_CZ, FRONT_Y + 0.03, 0.88)
bezel_inner = xz_prism(65.7, 17.7, 1.2, LCD_CZ, FRONT_Y + 0.2, 1.2)
body = body + (bezel_outer - bezel_inner)

# Protective annular button rims, exactly two.
for bz in BUTTON_Z:
    body = body + ring_y(0, bz, 14.0, 11.6, FRONT_Y + 0.03, 1.23)

body.label = "Housing - front shell"
body.color = BLACK

# --- Removable rear cover ---
# Recess fit: 0.3 mm per side; internal locating lip: 0.4 mm per side.
cover_plate = xz_prism(97.4, 131.4, 9.0, LID_RECESS_ZC, 17.0, 2.0)
cover_lip = xz_prism(93.2, 127.2, 7.0, LID_RECESS_ZC, 15.0, 1.5)
cover = cover_plate + cover_lip

# Four 2.9 mm clearance holes with shallow head seats for nominal small screws.
for bx, bz in BOSS_POS:
    cover = cover - y_cylinder(bx, bz, 15.25, 2.9, 3.7)
    # Smaller head seat leaves an annular shoulder for the screw head to bear on.
    cover = cover - y_cylinder(bx, bz, 16.55, 3.5, 0.9)

# Clearance through the locating lip so the buzzer body can approach the grille.
cover = cover - y_cylinder(BUZZER_X, BUZZER_Z, 14.25, 14.4, 1.7)

# Seven 1.8 mm acoustic ports aligned to the active buzzer.
cover_grille = [(0.0, 0.0)]
for i in range(6):
    import math
    a = math.radians(60 * i)
    cover_grille.append((4.0 * math.cos(a), 4.0 * math.sin(a)))
for dx, dz in cover_grille:
    cover = cover - y_cylinder(BUZZER_X + dx, BUZZER_Z + dz,
                               16.0, 1.8, 2.4)
cover.label = "Rear cover - removable"
cover.color = CHARCOAL

# --- Printed button actuators ---
# Cap head 10.2 mm in 10.8 mm bore; retaining collar 11.4 mm in 12.4 mm
# internal counterbore; 3.8 mm pusher shaft. 1.2 mm proud above the bezel.
def make_button(z, label, color):
    head = y_cylinder(0, z, -18.2, 10.2, 2.4)  # -19.4 .. -17.0
    shaft = y_cylinder(0, z, (-17.0 - 8.8) / 2, 3.8, 8.2)
    collar = y_cylinder(0, z, -14.15, 11.4, 1.0)
    cap = head + shaft + collar
    cap.label = label
    cap.color = color
    return cap

button_high = make_button(BUTTON_Z[0], "Round actuator - high priority", RED)
button_low = make_button(BUTTON_Z[1], "Round actuator - low / acknowledge", AMBER)

# --- Non-COTS mechanical/electronic envelopes for layout review ---
# LCD module: 80 x 36 PCB, 64 x 16 visible panel, I2C backpack on rear.
lcd_pcb = box_at(0, -13.6, LCD_CZ, 80.0, 1.6, 36.0)
lcd_pcb.label, lcd_pcb.color = "16x2 LCD PCB envelope 80x36", PCB_GREEN
lcd_glass = box_at(0, -15.05, LCD_CZ, 64.0, 1.3, 16.0)
lcd_glass.label, lcd_glass.color = "LCD visible area 64x16", LCD_BLUE
lcd_backpack = box_at(0, -9.05, LCD_CZ, 45.0, 7.5, 19.0)
lcd_backpack.label, lcd_backpack.color = "I2C backpack envelope", DARK

# ESP32 DevKit V1 generic envelope. USB connector assumed at lower short edge;
# exact connector/board variant is intentionally marked for physical confirmation.
esp_pcb = box_at(ESP_CX, 0.0, ESP_CZ, 28.0, 1.6, 52.0)
esp_pcb.label, esp_pcb.color = "ESP32 DevKit V1 PCB envelope 52x28", PCB_GREEN
esp_module = box_at(0, 5.0, 36.0, 18.0, 8.4, 23.0)
esp_module.label, esp_module.color = "ESP32 module envelope", METAL
usb_connector = box_at(0, 0.7, 1.0, 9.0, 7.0, 6.0)
usb_connector.label, usb_connector.color = "USB connector envelope - confirm variant", METAL

# Two rows of 15 generic header pins at 2.54 mm pitch.
esp_headers = []
for hx in (-12.0, 12.0):
    for i in range(15):
        hz = ESP_CZ - 17.78 + i * 2.54
        pin = box_at(hx, 3.3, hz, 1.0, 5.0, 1.0)
        pin.label, pin.color = f"ESP32 header pin {len(esp_headers)+1:02d}", METAL
        esp_headers.append(pin)

# Exactly two 5 mm LEDs; lens face is slightly recessed in the protective wells.
led_parts = []
for idx, lx in enumerate(LED_X):
    hue = GREEN if idx == 0 else RED
    name = "Green status LED 5mm" if idx == 0 else "Red alert LED 5mm"
    barrel = y_cylinder(lx, LED_Z, -11.4, 5.0, 8.0)
    lens = y_cylinder(lx, LED_Z, -16.15, 5.0, 0.7)
    led = barrel + lens
    led.label, led.color = name, hue
    led_parts.append(led)

# Exactly two axial current-limiting resistor envelopes, one per LED.
resistor_parts = []
for idx, rx in enumerate((-22.0, 22.0)):
    resistor = x_cylinder(rx, -5.0, LED_Z, 2.5, 6.5)
    # Through-hole leads extend 4 mm beyond each resistor body end.
    left_lead = x_cylinder(rx - 5.25, -5.0, LED_Z, 0.6, 4.0)
    right_lead = x_cylinder(rx + 5.25, -5.0, LED_Z, 0.6, 4.0)
    item = resistor + left_lead + right_lead
    item.label = f"LED current-limit resistor {idx+1} (220-330 ohm)"
    item.color = Color(0.72, 0.48, 0.16)
    resistor_parts.append(item)

# Exactly two 6x6 tactile switch envelopes, with small front-facing actuators.
switch_parts = []
for idx, bz in enumerate(BUTTON_Z):
    body_box = box_at(0, -5.85, bz, 6.0, 4.4, 6.0)
    plunger = y_cylinder(0, bz, -8.4, 1.8, 0.6)
    switch = body_box + plunger
    switch.label = f"6x6 tactile switch {idx+1} envelope"
    switch.color = DARK
    switch_parts.append(switch)

# One 12 x 7 mm active buzzer, facing the rear-cover grille.
buzzer_body = y_cylinder(BUZZER_X, BUZZER_Z, 10.5, 12.0, 7.0)
buzzer_body.label, buzzer_body.color = "Two-pin active buzzer 12x7 envelope", DARK
buzzer_pins = [
    box_at(BUZZER_X - 3.0, 5.75, BUZZER_Z, 0.8, 2.5, 1.0),
    box_at(BUZZER_X + 3.0, 5.75, BUZZER_Z, 0.8, 2.5, 1.0),
]
for i, pin in enumerate(buzzer_pins):
    pin.label, pin.color = f"Buzzer pin {i+1}", METAL

# Four generic M2.5-ish fastener envelopes. Shanks use slight pilot-hole
# interference intentionally to represent self-tapping engagement.
screw_parts = []
for bx, bz in BOSS_POS:
    shank = y_cylinder(bx, bz, 12.0, 2.0, 10.0)  # y 7..17
    head = y_cylinder(bx, bz, 17.75, 4.4, 1.5)  # y 17..18.5
    screw = shank + head
    screw.label = f"Rear cover screw {len(screw_parts)+1} (generic)"
    screw.color = METAL
    screw_parts.append(screw)

# Single colored assembly layout tree. COTS entries are reference envelopes,
# not supplier-exact models. Wires are omitted so clearances remain inspectable.
# Nested groups keep the enclosure and button parts in the exported STEP tree.
parts = [
    body, cover, button_high, button_low,
    lcd_pcb, lcd_glass, lcd_backpack,
    esp_pcb, esp_module, usb_connector, *esp_headers,
    *led_parts, *resistor_parts, *switch_parts,
    buzzer_body, *buzzer_pins, *screw_parts,
]
mechanical_items = [body, cover, *screw_parts]
mechanical_group = Compound(mechanical_items, label="Printed housing and fasteners",
                            children=mechanical_items)
front_items = [button_high, button_low, *led_parts, *switch_parts]
front_group = Compound(front_items, label="Front controls and indicators",
                       children=front_items)
display_items = [lcd_pcb, lcd_glass, lcd_backpack]
display_group = Compound(display_items, label="16x2 LCD module reference envelopes",
                         children=display_items)
controller_items = [esp_pcb, esp_module, usb_connector, *esp_headers]
controller_group = Compound(controller_items, label="ESP32 DevKit V1 reference envelopes",
                            children=controller_items)
passives_items = [*resistor_parts, buzzer_body, *buzzer_pins]
passives_audio_group = Compound(passives_items, label="Passives and buzzer reference envelopes",
                                children=passives_items)
assembly_groups = [mechanical_group, front_group, display_group,
                   controller_group, passives_audio_group]
assembly = Compound(assembly_groups, label="AETHER KEYNODE V1 - layout assembly",
                    children=assembly_groups)

# Separate print-ready body and cover exports plus printable button pair.
housing_export = Compound([body], label="AETHER KEYNODE V1 housing", color=BLACK)
cover_export = Compound([cover], label="AETHER KEYNODE V1 rear cover", color=CHARCOAL)
button_export = Compound([button_high, button_low], label="AETHER KEYNODE V1 round actuators")
export_step(housing_export, str(OUT / "keynode_v1_housing.step"))
export_step(cover_export, str(OUT / "keynode_v1_rear_cover.step"))
export_step(button_export, str(OUT / "keynode_v1_button_actuators.step"))
export_step(assembly, str(OUT / "keynode_v1_layout_assembly.step"))

# Purposeful Y-axis exploded arrangement: front modules move toward the user,
# the controller/buzzer toward the rear, and the cover/screws farther rearward.
def shifted(shape, dy, suffix="exploded"):
    moved = Pos(0, dy, 0) * shape
    moved.label = f"{shape.label} ({suffix})"
    moved.color = shape.color
    return moved

front_exploded = [
    shifted(button_high, -13), shifted(button_low, -13),
    shifted(lcd_pcb, -13), shifted(lcd_glass, -13), shifted(lcd_backpack, -13),
    *[shifted(part, -13) for part in led_parts],
    *[shifted(part, -13) for part in switch_parts],
    *[shifted(part, 8) for part in resistor_parts],
]
back_exploded = [
    shifted(esp_pcb, 8), shifted(esp_module, 8), shifted(usb_connector, 8),
    *[shifted(part, 8) for part in esp_headers],
    shifted(buzzer_body, 8), *[shifted(part, 8) for part in buzzer_pins],
]
cover_exploded = [shifted(cover, 20), *[shifted(part, 20) for part in screw_parts]]
front_group_exploded = Compound(front_exploded, label="Front modules exploded outward", children=front_exploded)
front_group_exploded.label = "Front modules exploded outward"
back_group_exploded = Compound(back_exploded, label="Controller and buzzer exploded rearward", children=back_exploded)
back_group_exploded.label = "Controller and buzzer exploded rearward"
cover_group_exploded = Compound(cover_exploded, label="Cover and fasteners exploded rearward", children=cover_exploded)
cover_group_exploded.label = "Cover and fasteners exploded rearward"
exploded_groups = [body, front_group_exploded, back_group_exploded, cover_group_exploded]
exploded = Compound(exploded_groups, label="AETHER KEYNODE V1 - exploded assembly", children=exploded_groups)
export_step(exploded, str(OUT / "keynode_v1_exploded_assembly.step"))

export_stl(body, str(OUT / "keynode_v1_housing.stl"), tolerance=0.08, angular_tolerance=0.25)
export_stl(cover, str(OUT / "keynode_v1_rear_cover.stl"), tolerance=0.08, angular_tolerance=0.25)
export_stl(button_export, str(OUT / "keynode_v1_button_actuators.stl"), tolerance=0.05, angular_tolerance=0.2)

print(f"Generated CAD deliverables in {OUT}")
print("Housing bounds:", body.bounding_box())
print("Cover bounds:", cover.bounding_box())
print("Assembly input components:", len(parts))
print("Assembly solids after union/shelling:", len(assembly.solids()))
print("Counts: 2 buttons, 2 LEDs, 2 resistors, 2 tactile switches, 1 buzzer, 1 LCD, 1 ESP32")
